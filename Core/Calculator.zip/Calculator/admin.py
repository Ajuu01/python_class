from django.contrib import admin

# Register your models here.
from Calculator.models import calculator_history

admin.site.register(calculator_history)